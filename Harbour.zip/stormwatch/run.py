import argparse
import csv
import json
from pathlib import Path
from harbour import simulate, safety_tests, command_backend


def main():
    parser = argparse.ArgumentParser(description="Stormwatch Harbour")
    parser.add_argument("--seed", type=int, default=11)
    parser.add_argument("--policy", choices=["baseline", "model", "harbour_fixture", "harbour_llm"], default="model")
    parser.add_argument("--evaluate", action="store_true")
    parser.add_argument("--test", action="store_true")
    parser.add_argument("--llm-command", nargs="+", help="Executable and arguments for a JSON stdin/stdout model adapter")
    args = parser.parse_args()
    out = Path(__file__).parent / "results"
    out.mkdir(exist_ok=True)
    if args.test:
        rows = safety_tests()
        assert all(row["passed"] for row in rows)
        for seed in (11, 12, 13, 14, 15):
            for policy in ("baseline", "model", "harbour_fixture"):
                assert simulate(seed, policy) == simulate(seed, policy)
        for seed in (11, 12, 13):
            model = simulate(seed, "model")
            rejected = simulate(seed, "harbour_llm", backend=lambda report: "invalid")
            assert rejected["cargo_delivered"] == model["cargo_delivered"]
            assert rejected["storm_knockouts"] == model["storm_knockouts"]
            assert rejected["invalid_outputs"] == rejected["fallback_uses"] == rejected["master_calls"]
        assert simulate(11, "harbour_llm", backend=lambda r: '{"action":"warn_storm"}')["invalid_outputs"] == 0
        (out / "safety_tests.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
        print("PASS: 10 safety cases, 15 repeatability pairs, 3 full-run fallback checks, valid-action control; conservation and grid bounds checked every tick.")
    elif args.evaluate:
        rows = [simulate(seed, policy) for policy in ("baseline", "model", "harbour_fixture") for seed in range(11, 16)]
        with (out / "results.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        (out / "results.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
        _, trace = simulate(11, "harbour_fixture", keep_trace=True)
        (out / "fixture_trace_seed11.json").write_text(json.dumps(trace, indent=2), encoding="utf-8")
        print(json.dumps(rows, indent=2))
    else:
        if args.policy == "harbour_llm" and not args.llm_command:
            parser.error("harbour_llm requires --llm-command; offline fixture is a separate policy")
        backend = (lambda report: command_backend(args.llm_command, report)) if args.llm_command else None
        result, trace = simulate(args.seed, args.policy, backend, keep_trace=True)
        (out / f"{args.policy}_{args.seed}_trace.json").write_text(json.dumps(trace, indent=2), encoding="utf-8")
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
