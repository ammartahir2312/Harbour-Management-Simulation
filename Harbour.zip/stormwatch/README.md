# Stormwatch Harbour

CGD-460 Assignment 2. Python 3.10+; simulation uses only the standard library.

## Run

From this directory:

```sh
python run.py --seed 11 --policy model
python run.py --seed 11 --policy baseline
python run.py --seed 11 --policy harbour_fixture
python run.py --evaluate
python run.py --test
```

Evaluation writes `results/results.csv`, `results/results.json` and a seed-11 fixture action trace. Tests write `results/safety_tests.json`. Single runs print metrics and save the Harbour Master trace. `results/summary.csv` contains computed means for seeds 11-13 and 11-15; `results/cargo_chart.svg` is the report chart.

## Files

- `run.py`: CLI, evaluation and executable tests.
- `harbour.py`: agents, seeded scenario, simulation and strict action validator.
- `results/`: measured runs, summary, chart, safety tests and fixture trace.

## Model and assumptions

Coordinates are zero-based: x=0..23 west to east, y=0..15 north to south. B1=(3,0), B2=(9,0), B3=(15,0), B4=(21,0); warehouse=(0,15). Ten workers start at the warehouse. All cells are passable; workers may share cells. Ship queues are unbounded and FIFO among ships not currently held. Each ship carries 8 cargo units, leaves once its last unit is picked up, and has a unique integer ID.

Each run processes ticks 0..599. One `random.Random(seed)` generates all arrival intervals (inclusive 6..10 ticks) and three storm starts sampled without replacement from 60,85,...,560. This avoids overlapping storms; each lasts exactly 15 ticks. Warnings start at s-5. All events are generated before policies execute, so comparisons use the same weather and arrivals without depending on policy-specific random draws. Future events are not passed to the Harbour Master.

Tick order: arrivals and lookout update; Harbour Master decision when due; berth admission; storm contact; worker actions in stable index order; empty-ship departure. A worker can move one orthogonal cell, pick up one unit or drop off one unit per tick. Bookkeeping and quartermaster decisions are not worker actions. A storm contact at B1/B4 causes one knock-out, loses any carried unit, teleports the worker to the warehouse and prevents work for 10 ticks including the contact tick. These consequences are explicit assumptions because the brief does not define them. Ships are never newly admitted to B1/B4 during an active storm.

Quartermaster reserves available cargo and prefers the lowest numbered eligible berth; existing valid reservations persist. The baseline ignores warnings and continues assignments. The model-based policy stores a warning deadline through the end of the storm, cancels unsafe assignments, avoids B1/B4, and evacuates idle workers from those cells. Loaded workers continue returning to the warehouse. Routes leave row 0 before crossing horizontally; thus a worker travelling to B2 does not accidentally pass through B1. All policies share this movement rule. No collision or congestion model is implemented.

Cargo conservation and map bounds are asserted every tick. Tests check exact repeatability, all four specified safety categories plus parser/type attacks, valid-action acceptance, and full-run fallback equivalence. The finite seed set cannot prove universal performance.

## Harbour Master and honest evaluation scope

`harbour_fixture` is a deterministic scripted test double, **not an LLM**. It returns warn_storm when a warning is present or no ship is waiting; otherwise it holds the first waiting ship for 10 ticks. It is queried every 10 ticks and at warning onset. A warning action only relays genuine sensor information; it does not create a false storm. Both Harbour Master modes retain the model-based worker controller as the safety layer. Valid holds affect admission; invalid proposals execute no action and use that controller. There is no privileged close, release-cargo or approval-bypass action.

Allowed JSON: `{"action":"warn_storm"}` or `{"action":"hold_ship","ship_id":3}`. Exact key sets are required, ship IDs must be integers (not booleans) and must appear in the current waiting list. Bare function calls, unknown actions, extra keys, unknown ships, bad JSON, command failures and timeouts are rejected. Output is parsed with `json.loads`, never `eval`.

An optional real-model adapter is supported:

```sh
python run.py --seed 11 --policy harbour_llm --llm-command python my_adapter.py
```

The adapter must read one JSON object from stdin containing trusted `instruction` and untrusted `report`, call the chosen model, and print only its JSON action. Use environment variables for secrets. The adapter is not included and no real API was called. Do not rename fixture metrics as LLM metrics. To complete a live evaluation, run the adapter for seeds 11,12,13, retain traces and record model/version, prompt, settings, errors and metrics; update the report accordingly.

## Submission status

The PDF is a worked draft with an honest AI declaration. It needs your own review and understanding. No student name or ID was invented. The assignment requests a hosted repository link: this local package does not provide a hosted URL. Create a repository in your account, upload these files and add its real URL to the submission. Review the declaration and record only checks you actually perform. No credentials are included.

The main task instructions request seeds 11-13 while the settings table says 11-15. All five are supplied; the report uses 11-13 as its primary comparison.
